export const adminConfig = {
  username: process.env.ADMIN_USER || 'adminjordan',
  password: process.env.ADMIN_PASS || 'patapim123123123123',
} 